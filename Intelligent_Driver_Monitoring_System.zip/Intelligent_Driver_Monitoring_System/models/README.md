# Models

This prototype uses OpenCV Haar Cascade models supplied through the installed `opencv-python` package, so separate XML model files are not required.

For a future deep-learning version, trained model files can be placed in this folder and loaded by the application.
